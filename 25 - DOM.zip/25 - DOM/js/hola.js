alert("Hola!!")
console.log(document.querySelector("div"))
